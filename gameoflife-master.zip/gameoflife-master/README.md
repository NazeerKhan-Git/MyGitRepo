[ ![Codeship Status for fransguelinckx/gameoflife](https://codeship.com/projects/cc690260-7e5b-0133-a110-3e77708a93d7/status?branch=master)](https://codeship.com/projects/120303)

# gameoflife

### Build backend + run (localhost:8080)
```
# ./mvnw spring-boot:run
```

### Build frontend + backend + run (localhost:8080)
```
# ./mvnw spring-boot:run -Pgrunt
```

### Build backend + run + watch front-end changes (localhost:3000)
```
# ./mvnw spring-boot:run
# grunt
```
