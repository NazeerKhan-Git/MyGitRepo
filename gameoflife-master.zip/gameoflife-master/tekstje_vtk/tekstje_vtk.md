Achievements:
[v] Basics
Learned to write 1+1
Unlocked during BVP

[v] Object-Oriented Design
Learned to write ONE.plus(ONE)
Unlocked during OGP

[v] Design Patterns
Learned to write MathBuilder.add(ONE).add(ONE).calculate()
Unlocked during SWOP

[ ] Simplicity
Learned to write 2
Not yet unlocked?


So you think you can code?
==========================

As developers, we want to write code that is understandable, maintainable and extensible. At Cegeka, we don't do this by adding more abstractions or design patterns. We think about simple, explicit code, using abstraction and patterns only where needed. During this workshop, you will be experimenting with various techniques to gain a better understanding of how to write good code. Achievement unlocked!

